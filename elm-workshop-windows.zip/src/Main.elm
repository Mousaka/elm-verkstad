module Main exposing (main)

import Html


main =
    Html.text "Hello, world!"
